<?php

class EigenAuto extends Auto 
{
    public $aankoopdatum;
    
    function __construct($aankoopdatum){
        $this->aankoopdatum;
    }
 
}

?>