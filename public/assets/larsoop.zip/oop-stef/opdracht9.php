<?php 
    require 'Auto.php';
    session_start();

  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['Merk'])){
    $newCar = new Auto($_POST['Merk'], $_POST['Type'], $_POST['Kleur'],
                    $_POST['Trekhaak'], $_POST['Kenteken'], $_POST['kilometers'],
                    $_POST['Tankinhoud'], $_POST['Benzine'], $_POST['Verbruik']
    );
    $_SESSION['autos'][] = $newCar;
  }
   elseif (isset($_POST['rijden'])) {
    $counter = 1;
    foreach ($_SESSION['autos'] as $auto){
        if ($counter == (int)$_POST['nummer']){
          $auto->rijden($_POST['rijden']);

        }
        $counter += 1;
    }
   }
   elseif (isset($_POST['liters'])) {
    $counter = 1;
    foreach ($_SESSION['autos'] as $auto){
        if ($counter == (int)$_POST['nummer']){
          $auto->tanken($_POST['liters']);

        }
        $counter += 1;
    }
   }
  }else{
    if (!isset($_SESSION['$autos'])){
      $_SESSION['autos'] = array();


  }
  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opdracht9-StefLangerak</title>
</head>
<body>

<style>
  form  { 
    color: blue;
  }

  td{ 
    background : lightblue;
  }

  h2 { 
    color: blue;
    font-weight : 800;
  }
</style>


<h2>Voer gegevens in: </h2>

<form name="auto" id="auto" method="post">
  <label for="fname">Merk</label><br>
  <input type="text" id="Merk" name="Merk" ><br><br>

  <label for="lname">Type:</label><br>
  <input type="text" id="Type" name="Type" ><br><br>

  <label for="lname">Kleur: </label><br>
  <input type="text" id="Kleur" name="Kleur" ><br><br>

  <label for="lname">Trekhaak: </label><br>
  <input type="text" id="Trekhaak" name="Trekhaak" ><br><br>

  <label for="lname">Kenteken: </label><br>
  <input type="text" id="Kenteken" name="Kenteken" ><br><br>

  <label for="lname">kilometers: </label><br>
  <input type="text" id="kilometers" name="kilometers" ><br><br>

  <label for="lname">Tankinhoud: </label><br>
  <input type="text" id="Tankinhoud" name="Tankinhoud" ><br><br>

  <label for="lname">Benzine: </label><br>
  <input type="text" id="Benzine" name="Benzine" ><br><br>

  <label for="lname">Verbruik: </label><br>
  <input type="text" id="Verbruik" name="Verbruik" ><br><br>

  <input type="submit" value="Submit">

</form> 



<h2> Rijden </h2>
<form method="post" name="rijden">
  <label for="fname">Over welke auto gaat het (voor ID nummer uit de tabel in):</label><br>
  <input type="text" id="nummer" name="nummer" ><br>

  <label for="fname">Voer aantal te rijden kilometers in:</label><br>
  <input type="text" id="rijden" name="rijden" ><br>

  <input type="submit" value="Voeg toe"> <br><br>
</form>

<h2>Voer liters voor tanken in:</h2>
<form method="post" name="tanken">
<label for="fname">Over welke auto gaat het (voor ID nummer uit de tabel in):</label><br>
  <input type="text" id="nummer" name="nummer" ><br>

<label for="fname">Tanken</label><br>
  <input type="text" id="liters" name="liters" ><br>

<input type="submit" value="Voeg toe"><br>
</form>


</body>
</html>

<?php
 echo "<table border='1'>
 <tr>
 <th> ID</th>
 <th> Merk</th>
 <th> Type</th>
 <th> Kleur</th>
 <th> Trekhaak</th>
 <th> Kenteken</th>
 <th> Kilometers</th>
 <th> Tankinhoud</th>
 <th> Benzine </th>
 <th> Verbruik</th>
 </tr>";
$counter = 1;
 foreach ($_SESSION['autos'] as $auto){
    echo "<tr>";
    echo "<td>" .$counter."</td>";
    echo "<td>" .$auto->get_merk()."</td>";
    echo "<td>" .$auto->get_type()."</td>";
    echo "<td>" .$auto->get_kleur()."</td>";
    echo "<td>" .$auto->get_trekhaak()."</td>";
    echo "<td>".$auto->get_kenteken()."</td>";
    echo "<td>" .$auto->get_kilometers()."</td>";
    echo "<td>" .$auto->get_tankinhoud()."</td>";
    echo "<td>" .$auto->benzinepeil()."</td>";
    echo "<td>" .$auto->get_verbruik()."</td>";
    echo  "</tr>";
    $counter += 1;
}
 
?>


