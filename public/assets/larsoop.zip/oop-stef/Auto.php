<?php 
    class Auto { 
        public $merk;
        public $type;
        public $kleur;
        public $trekhaak;
        protected $kenteken; 
        protected $kilometers= 0;  
        public $tankinhoud;
        protected $benzine= 0;
        public float $verbruik;
     
         function __construct($merk, $type, $kleur, $heeftTrekhaak= false, $kenteken, $kilometers=0, $tankinhoud, $benzine=0, $verbruik){
            $this->merk = $merk;
            $this->type = $type;
            $this->kleur = $kleur;
            $this->trekhaak = $heeftTrekhaak;
            $this->kenteken = $kenteken;
            $this->kilometers = $kilometers;
            $this->tankinhoud = $tankinhoud;
            $this->benzine=$benzine;
            $this->verbruik=$verbruik;
        }

        

        function get_merk(){
            return $this->merk;
        }
        function get_type(){
            return $this->type;
        }
        function get_kleur(){
            return $this->kleur;
        }
        function get_trekhaak(){
            if ($this->trekhaak){
                return "aanwezig";
            }
            else{
                return "niet aanwezig";
            }
        }
        function get_kenteken(){
            return $this->kenteken;
        }
        function get_kilometers(){
            return $this->kilometers;
        }
        function get_tankinhoud(){
            return $this->tankinhoud;
        }
        function get_verbruik(){
            return $this->verbruik;
        }
        function tanken($liters){ 
                $this->benzine += $liters;
            if ($this->benzine > $this->tankinhoud) { 
                
                $teveel = $this->benzine - $this->tankinhoud;

                $this->benzine = $this->tankinhoud;

                return $teveel;
            } else { 
                return 0;
            }
        }

        function rijden($te_rijden_km){ 
            $verbruikt = ($te_rijden_km) * ($this->verbruik / 100);
         if ($verbruikt < $this->benzine){
            $this->kilometers += $te_rijden_km;
            $this->benzine -= $verbruikt;
            return $te_rijden_km;
         } else { 
            $nog_te_rijden = ($this->benzine * 100) / $this->verbruik;
            $this->kilometers += $nog_te_rijden;
            $this->benzine -= ($nog_te_rijden) * ($this->verbruik / 100);
            return $nog_te_rijden;
         }

        }

        function kilometerstand(){
            return $this->kilometers;
        }

        function getKenteken(){
            return $this->kenteken;
        }

        function setKenteken($kenteken){
            $kenteken = strtoupper($kenteken);

            $kenteken = preg_replace('/[^A-Z0-9\-]/','', $kenteken);

            $this->kenteken = $kenteken;
        }

        function benzinepeil(){
            return $this->benzine;
        }
}


                                                                                      
    ?> 

 

