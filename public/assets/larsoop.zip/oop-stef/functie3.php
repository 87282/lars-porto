<?php 

function magStemmen($stemmen){
    if (is_numeric($stemmen) && $stemmen >= 18) { 
        return true ;
    }

    else { 
        return false ;
    }
    
}

$stemmen = 15;
if (magStemmen($stemmen)){
    echo "Je mag stemmen stemmen <br/>";
} else { 
    "Je mag niet stemmen <br />";
}

$stemmen = 20;
if (magStemmen($stemmen)){
    echo "Je mag stemmen stemmen <br/>";
} else { 
    "Je mag niet stemmen <br />";
}

$stemmen = 'TT';
if (magStemmen($stemmen)){
    echo "Je mag stemmen stemmen <br/>";
} else { 
    "Je mag niet stemmen <br />";
}



?>