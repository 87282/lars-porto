<?php
    require 'Auto.php';

    $auto1 = new Auto("Audi", "A3", "Grijs", true, "PK-69-69", 12345, 60, 40, 10);
    $auto2 = new Auto("Audi", "A6", "blauw", true, "DD-223-12", 2345, 70, 70, 12);
    $auto3 = new Auto("Mercedes", "A45", "rood", false, "GG-134-42", 245455, 80,70, 14);
    $auto_list = [$auto1, $auto2, $auto3];


    foreach ($auto_list as $auto){
        echo "<br/> <br/> Het merk is: " .$auto->get_merk();
        echo " <br/> Het type is: " .$auto->get_type();
        echo "<br/>  De kleur is: " .$auto->get_kleur();
        echo "<br/> Trekhaak: " .$auto->get_trekhaak();
        echo "<br/> Het kenteken is: ".$auto->get_kenteken();
        echo "<br/> De kilometerstand is: " .$auto->get_kilometers();
        echo "<br/> De tankinhoud is: " .$auto->get_tankinhoud(). " Liter";
        echo "<br/> Het verbruik is:" .$auto->get_verbruik(). "Liter per 100KM </br>";

    }

        echo "<br/> De " .$auto1->get_merk()." ".$auto1->get_type(). " wilt 20Km rijden en heeft daadwerkelijk ".$auto1->rijden(20)."km gereden. 
        De kilometerstand is ".$auto1->get_kilometers().". Er zit nog ".$auto1->get_tankinhoud()." liter in de tank.";
        echo "<br/> De " .$auto2->get_merk()." ".$auto2->get_type(). " wilt 40 liter tanken en heeft daadwerkelijk ".$auto2->tanken(40)." liter getankt. 
        De kilometerstand is ".$auto2->get_kilometers().". Er zit in totaal ".$auto2->get_tankinhoud()." liter in de tank.";
?>