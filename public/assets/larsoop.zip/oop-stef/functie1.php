<?php 



function berekenKamer($lengte, $breedte, $hoogte=null ) { 
    if ( $hoogte != null){
        echo "<br/> de inhoud: " . $lengte * $breedte * $hoogte;
    }
    else{
        echo "de oppervlakte: " .$lengte * $breedte;
    }
} 

    berekenKamer(2,3);
    berekenKamer(2,3,4);

?>