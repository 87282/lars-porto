<?php

function nlDatum($date ){
    $datum = strtotime($date);
    echo date('d-M-y', $datum);  
    }

 nlDatum("2022-12-13");


?>