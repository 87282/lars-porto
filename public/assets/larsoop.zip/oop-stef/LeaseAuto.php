<?php 


class LeaseAuto extends Auto 
{ 
   
    public $leasemaatschappij;
    public $start_contract;
    public $einde_contract;
    private $laatste_onderhoud;

    function __construct($leasemaatschappij, $start_contract, $einde_contract, $laatste_onderhoud = date('d-m-y h:i:s')){
        $this->leasemaatschappij;
        $this->start_contract;
        $this->einde_contract;
        $this->laatste_onderhoud;
    }

}



?>